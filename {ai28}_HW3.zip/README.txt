To run SNAKE

1. Open the html file on a browser.
2. Press any button on the keyboard to start the game

To stop

1. Press the stop button 

To restart

1. Reload the page if you have hit the boarders or the snakes body
2. Else, hit the stop button again. 

=========================================================================


To run hw4

1. node hw4.js (on terminal/console)