var rs = require('readline-sync');

var fNum1 = rs.question('1st Number: ');
var fNum2 = rs.question('2nd Number: ');
var fNum3 = rs.question('3nd Number: ');
var fNum4 = rs.question('4nd Number: ');

function factorial(num)
{
    if(num ==0 || num ==1)
    {
        return 1;
    }
    for(var i = num-1; i >= 1 ; i--)
    {
        num *= i;
    }
    return num;
}

var result2 = factorial(fNum1)
console.log("Factorial of the 1st number is = " + result2);

function sumDigits(num){
    var value = num;
    sum = 0;
    while(value)
    {
        sum += value%10;
        value = Math.floor(value/10);
    }
    return sum;
}

var result3 = sumDigits(fNum2);
console.log("The sum of all the digits of the 2nd number is = "+result3);


function reverseNum(num)
{
   var reversed = 0;
   while(num != 0)
   {
       reversed *= 10;
       reversed += num %10;
       num -=num %10;
       num /= 10;

   } 
   return reversed;
}
var result4 = reverseNum(fNum3);
console.log("The reverse of the 3rd number is = " + result4);

function isPalindrome(num)
{
    var rem, temp, final = 0;
    temp = num;
    while(num > 0)
    {
        rem = num%10;
        num = parseInt(num/10);
        final = final*10+rem;

    }
    if(final == temp)
    {
        console.log("Is the 4th number a palindrome (True/False)? = True");
    }
    else console.log("Is the 4th number a palindrome (True/False)? = False");
}

isPalindrome(fNum4);